<div class="btn-group pull-right">
	<button class="btn btn-inverse" onclick="modal('vst-moneda-insertmonval','')">
		<i class="fa fa-plus"></i>
		Agregar Referencia de Moneda
	</button>
</div>
<div class="clearfix"></div>
<div class="space-6"></div>
<div class="lista"></div>
<script>
	load('vst-moneda-listamonval','','.lista');
</script>