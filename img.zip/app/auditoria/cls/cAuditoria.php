<?php class cAuditoria extends mAuditoria {
	

} ?>