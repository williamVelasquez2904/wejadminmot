<div class="btn-group pull-right">
	<button class="btn btn-inverse" onclick="modal('vst-modelo-insert','')">
		<i class="fa fa-plus"></i>
		Agregar Modelo
	</button>
</div>
<div class="clearfix"></div>
<div class="space-6"></div>
<div class="lista"></div>
<script>
	load('vst-modelo-lista','','.lista');
</script>