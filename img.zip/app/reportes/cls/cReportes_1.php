<?php 
class cReportes extends mReportes {
	
}
?>