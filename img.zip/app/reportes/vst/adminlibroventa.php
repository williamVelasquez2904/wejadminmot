<div class="libroventa"></div>
<script>
	load('vst-reportes-parametrolibrodeventa','','.libroventa');
</script>