<div class="lista_cobranza"></div>
<script>
	load('vst-reportes-parametrocobranza','','.lista_cobranza');
</script>