<div class="lista"></div>
<script>
	load('vst-reportes-listareq','','.lista');
</script>