<div class="libroinventariomensual"></div>
<script>
	load('vst-reportes-parametrolibrodeinventariomensual','','.libroinventariomensual');
</script>