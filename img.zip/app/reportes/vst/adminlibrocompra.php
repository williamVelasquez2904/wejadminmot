<div class="librocompra"></div>
<script>
	load('vst-reportes-parametrolibrodecompra','','.librocompra');
</script>