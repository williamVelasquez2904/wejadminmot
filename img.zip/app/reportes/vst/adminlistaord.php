<div class="lista"></div>
<script>
	load('vst-reportes-listaord','','.lista');
</script>