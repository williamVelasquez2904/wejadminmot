<div class="cuadre"></div>
<script>
	load('vst-reportes-cuadrecaja','','.cuadre');
</script>