<?php 
require '../../../cfg/base.php';
 $mchat->guardaChat();
?>