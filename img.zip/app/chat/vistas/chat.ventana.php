<title>Chat Historias Medicas</title>
<link rel="stylesheet" href="../../../lib/bootstrap.ace/assets/css/bootstrap.min.css">
<link rel="stylesheet" href="../../../lib/font-awesome-4.4.0/css/font-awesome.min.css">
<link rel="stylesheet" href="../../../lib/bootstrap.ace/assets/css/ace.min.css" />
<link rel="stylesheet" href="../../../lib/bootstrap.ace/assets/css/ace-rtl.min.css" />
<link rel="stylesheet" href="../../../lib/bootstrap.ace/assets/css/ace-skins.min.css" />

<script type="text/javascript">
	window.jQuery || document.write("<script src='../../../lib/bootstrap.ace/assets/js/jquery-2.0.3.min.js'>"+"<"+"/script>");
</script>
<script type="text/javascript" src="../../../js/funciones.js"></script>
<script type="text/javascript" src="../../../lib/chat/js/chat2.js"></script>
<div class="chatgloss1"></div>
 <script type="text/javascript">
    load('chat.window.php','','.chatgloss1'); 
</script>