<input type="text" name="observ" value="osevervacio">
