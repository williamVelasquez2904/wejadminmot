<div class="btn-group pull-right">
	<button class="btn btn-inverse" onclick="modal('vst-producto-insertretiro','')">
		<i class="fa fa-plus"></i>
		Agregar Retiro o Auto-Consumo
	</button>
</div>
<div class="clearfix"></div>
<div class="space-6"></div>
<div class="lista"></div>
<script>
	load('vst-producto-listaretiro','','.lista');
</script>