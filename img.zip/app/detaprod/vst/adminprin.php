<div id="detaprod"></div>
<script>
	load('vst-detaprod-admin','','#detaprod');
</script>