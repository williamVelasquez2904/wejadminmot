<?php 
extract($_POST); ?>
<div class="clearfix"></div>
<div class="space-6"></div>
<div class="parametros"></div>
<div class="resumen"></div>
<script>
	modal('vst-desglose-parametros_resumen_desglose','desg_ide=<?php echo $desg_ide ?>');
</script> 