<?php require '../../../cfg/base.php'; ?>
<div class="form-group col-sm-12 col-xs-12">
		<div class="col-sm-12">
			<input type="text" class="form-control" id="buscarcliente" name="clien">
		</div>
</div> 