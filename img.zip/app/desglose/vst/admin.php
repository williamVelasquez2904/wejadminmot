<div class="btn-group pull-right">
	<button class="btn btn-inverse" onclick="modal('vst-desglose-insert','')">
		<i class="fa fa-plus"></i>
		Agregar Desglose [admin.php]. 08-01-2025
	</button>
</div>
<div class="clearfix"></div>
<div class="space-6"></div>
<div class="main"></div>
<div class="clearfix"></div>
<div class="venta"></div>
<div class="resumen"></div>

<script>
	load('vst-desglose-lista','','.main');
</script>