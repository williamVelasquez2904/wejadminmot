<?php class cDesglose extends mDesglose {
	



} ?>