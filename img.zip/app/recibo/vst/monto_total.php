<div class="col-sm-12 col-xs-12">
	<input type="text" class="form-control" name="mto_total" id="mto_total" >
</div>