<?php 
extract($_POST);
var_dump($ide);
?>