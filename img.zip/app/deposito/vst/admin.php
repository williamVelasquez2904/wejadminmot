<div class="btn-group pull-right">
	<button class="btn btn-inverse" onclick="modal('vst-deposito-insert','banco_ide=1')">
		<i class="fa fa-plus"></i>
		Agregar Deposito
	</button>
</div>
<div class="clearfix"></div>
<div class="space-6"></div>
<div class="lista"></div>
<script>
	load('vst-deposito-lista','','.lista');
</script>