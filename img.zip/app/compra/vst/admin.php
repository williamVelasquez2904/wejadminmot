<div id="datocompra"></div>
<script>
	load('vst-compra-adminprin','','#datocompra');
</script>