<div class="lista"></div>
<script>
	load('vst-compra-listacompra','','.lista');
</script>