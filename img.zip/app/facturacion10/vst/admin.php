<div id="datofact"></div>
<script>
	load('vst-facturacion10-adminprin','','#datofact');
</script>