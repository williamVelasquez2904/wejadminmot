<div class="lista"></div>
<script>
	load('vst-facturacion10-listafactura','','.lista');
</script>