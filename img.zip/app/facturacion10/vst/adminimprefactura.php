<div class="lista"></div>
<script>
	load('vst-facturacion10-listaimprefactura','','.lista');
</script>