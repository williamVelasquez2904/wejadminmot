<div id="datonoen"></div>
<script>
	load('vst-notaentre-adminprin','','#datonoen');
</script>