<div class="lista"></div>
<script>
	load('vst-notaentre-listanotaentre','','.lista');
</script>