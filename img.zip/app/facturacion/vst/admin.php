<div id="datofact"></div>
<script>
	load('vst-facturacion-adminprin','','#datofact');
</script>