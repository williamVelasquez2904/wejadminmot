<div class="lista"></div>
<script>
	load('vst-facturacion-listaimprefactura','','.lista');
</script>