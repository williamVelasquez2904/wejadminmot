<div class="lista"></div>
<script>
	load('vst-facturacion-listafactura','','.lista');
</script>