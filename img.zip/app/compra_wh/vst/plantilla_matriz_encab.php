<thead> 
	<tr>
		<?php 
            $ancho = "8%";
            $ancho_num = "5%";
        ?>
<!-- 
		<th width="2%">Id</th>
		<th width="<?php //echo $ancho; ?>">Prov</th>
		 -->
		<th width="<?php echo $ancho; ?>">Fecha Factura</th>
		<th width="<?php echo $ancho; ?>">Fecha Recep</th>
		<th width="20%">Cliente </th>
		<th width="<?php echo $ancho; ?>">Num Factura</th>
		<th width="<?php echo $ancho_num; ?>">% Desc.</th>
		<th width="<?php echo $ancho_num; ?>">Monto </th>
		<th width="<?php echo $ancho_num; ?>">Devol. </th>
		<th width="<?php echo $ancho_num; ?>">Comisión</th>
		<th width="<?php echo $ancho_num; ?>">Com. AutoAsia</th>
		<th width="<?php echo $ancho; ?>">Abono </th>
		<th width="<?php echo $ancho_num; ?>">Saldo </th>
<!-- 		<th width="<?php //echo $ancho; ?>">Estatus</th>-->
		<th width="3%">Opciones</th>				
	</tr>
</thead>