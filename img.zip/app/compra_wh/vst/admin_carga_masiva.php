<div class="lista_temporal">
<script>
	load('vst-compra_wh-lista_temporal','','.lista_temporal');
</script>