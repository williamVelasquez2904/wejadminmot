<div class="resumen">
<script>
	/*load('vst-compra_wh-lista_parametros','','.lista_parametros');*/
	load('vst-compra_wh-resumen','','.resumen');
</script> 