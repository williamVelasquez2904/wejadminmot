<?php 
echo "prueba 22/10/2024";
?>