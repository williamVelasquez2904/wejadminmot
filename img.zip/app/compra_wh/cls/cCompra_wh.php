<?php class cCompra_wh extends mCompra_wh {
	



} ?>