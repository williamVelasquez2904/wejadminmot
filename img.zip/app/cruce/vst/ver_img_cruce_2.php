<?php require '../../../cfg/base.php'; ?>	
	<?php echo $fn->modalHeader('Imágen cruce') ?>
	<div class="modal-body">
		<div class="form-group">
			<div class="col-sm-8">
				<img src="img/pagos/370_Kleman_Rondon.png"></img>	
				<!-- 
				<img src="/img/pagos/370_Kleman_Rondon.png">
				<img src="/../../../img/pagos/370_Kleman_Rondon.png">
				<img src="../../../img/pagos/370_Kleman_Rondon.png">
				<img src="/../../img/pagos/370_Kleman_Rondon.png">
				<img src="/../img/pagos/370_Kleman_Rondon.png">
				<img src="../img/pagos/370_Kleman_Rondon.png"> -->
			</div>
		</div>
	<div class="col-sm-8"><?php echo $fn->modalFooter(1) ?></div>
	</div>
	<div class="clear-fix"></div>
	
	