<div class="btn-group pull-right">
	<button class="btn btn-inverse" onclick="modal('vst-forpago-insert','')">
		<i class="fa fa-plus"></i>
		Agregar Forma de Pago
	</button>
</div>
<div class="clearfix"></div>
<div class="space-6"></div>
<div class="lista"></div>
<script>
	load('vst-forpago-lista','','.lista');
</script>