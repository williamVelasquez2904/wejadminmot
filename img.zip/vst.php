<?php require 'cfg/base.php'; ?>
<?php require 'app/'.$_GET['app'].'/vst'.$_GET['vst'].'/'.$_GET['file'].'.php'; ?>